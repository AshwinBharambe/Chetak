<?php 

require_once("connection.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Assignment 5</title>
		<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
	body{ color:black ; font-size: 17px;  background-image:linear-gradient(to right top, #E91E63, #FF9800, #8BC34A, #8BC34A, #e91e7e); }
	form{ border:2px solid black; margin: 50px; padding: 30px; border-radius: 10px;  background-image:linear-gradient(to right top, #2196F3, #3F51B5, #673AB7, #9C27B0, #03A9F4); }
	legend{ color: white; text-align: center; font-size: 5rem; }
	</style></head>
<body>
<div class="container">
		<form  method="post">						
			  <form>
   					<fieldset>
  					<legend>National Workshop on Web Technology</legend>
    				<div class="form-group">
                         <label>FirstName:</label>
                         <input type="text" id="fname" class="form-control" name="FirstName" data-placeholder="NAME" required><br>
					</div>
					<div class="form-group">
						<label>LastName: </label>
						<input type="text" id="lname"  class="form-control" name="LastName" required ><br>
				   </div>
				   <div class="form-group">
						<label>Email:</label>
						<input type="text" id="maill" class="form-control" name="Email" required><br>
					</div>
					<div class="form-group">
						<label>Password: </label>
					   <input type="Password" id="pwd" class="form-control" name="pwd" data-placeholder="PASSWORD" required><br>
					</div>
					<div class="form-group">
						<label>City: </label>
					  <select id="country" name="Country" required class="form-control">
					   <option value="Ahmedabad">Ahmedabad</option>
					   <option value="Surat">Surat</option>
					   <option value="Nadiad">Nadiad</option>
					   <option value="Anand">Anand</option>
					   <option value="Vadodara">Vadodara</option>
					   <option value="Pune">Pune</option>
					   <option value="Banglore">Banglore</option>
					</select></div>
					<div class="form-group">	
						<label>I am a : </label><br>
  						<input type="radio" id="Student"  name="type" value="Student">
						<label for="Student">Student</label><br>
						<input type="radio" id="Faculty" name="type" value="Faculty">
						<label for="Faculty">Faculty</label><br>
						<input type="radio" id="Hod" name="type"  value="Hod">
						<label for="Hod">Hod</label><br>
                        <input type="radio" id="principal" name="type"  value="principal">
						<label for="principal">principal</label><br>
                    </div>
                    <div class="form-group">
						<input  type="submit" class="btn btn-warning" name="submit" value="Register">
					</div>
			</form>	
	</div>
</div>
</div>
</body>
</html>
<?php
	if ($_SERVER["REQUEST_METHOD"]=="POST")
	{
		if (isset($_POST["FirstName"]) && isset($_POST["LastName"]) && isset($_POST["Email"]) && isset($_POST["Country"]) && isset($_POST["type"]) && isset($_POST["pwd"]))
		{
			$fname=$_POST["FirstName"];
			$lname=$_POST["LastName"];
			$email=$_POST["Email"];
			$pwd=$_POST["pwd"];
			$country=$_POST["Country"];
			$work=$_POST["type"];

			if($fname!=' ' && $lname!=' ' && $email!=' ' && $country!=' ' && $work!=' ' && $pwd)
			{
				$sql = "insert into student(FirstName,LastName,Email,Country,type,pwd)values('".$fname."','".$lname."','".$email."','".$country."','".$work."','".md5($pwd)."')";
				$result=mysqli_query($conn,$sql);
				print_r($result);
				die;
				if($result)
				{
					echo "<script>alert('Record inserted');document.location='assign5.php'</script>";
				}
			}
		}
		else
		{
			echo"value not set";
		}
	}
?>